<?php
/**
 * Single-Popup Templates
 *
 * @package   PUM
 * @copyright Copyright (c) 2023, Code Atlantic LLC
 */

get_header(); ?>

<?php
get_footer();
